<!-- Categoria Smartphones -->

  
  <div id=painel>
    <div class="row row-cols-1 row-cols-md-3 g-4" id="fundopainel">
    <?php
  $sql = "SELECT `id`, `nome`, `imagem`, `descricao` `preco` FROM `jogos` WHERE 1";

  $todos = mysqli_query($conn, $sql);

    while ($dados=mysqli_fetch_array($todos)) {?>

      <div class="col">
        <a href="https://store.steampowered.com/app/627270/Injustice_2/" class="nav-link">
          <div class="card">
            <img src="<?=$dados['imagem'];?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title"><?=$dados['nome'];?></h5>
              <p class="card-text"><?=$dados['descricao'];?></p>
              <h8 class="card-text" id="preco">R$ <?=$dados['preco'];?></h8>
              
              
            </div>
          </div>
        </a>  
      </div>
      <?php } ?>
      
    </div>
  </div>


</main>


    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>


<!-- imagens, preços,links para redirecionamento de produtos e categorias dos produtos -->