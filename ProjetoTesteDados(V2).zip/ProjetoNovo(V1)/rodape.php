
<div class="b-example-divider"></div>

<div class="container">
  <footer class="py-3 my-4">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3">
      <li class="nav-item"><a href="#" class="nav-link px-2 text-white">Home</a></li>
      <li class="nav-item"><a href="#" class="nav-link px-2 text-white">Quem Somos</a></li>
      <li class="nav-item"><a href="#" class="nav-link px-2 text-white">Fale Conosco</a></li>
    </ul>
    <p class="text-center text-white">&copy; 2022 Company, Inc</p>
  </footer>
</div>


<!-- fale conosco, redirecionar para o começo do site e checar sites -->
</body>
</html>