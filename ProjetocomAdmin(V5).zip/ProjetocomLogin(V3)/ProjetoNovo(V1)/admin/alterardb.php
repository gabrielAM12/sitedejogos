<?php

$id =      $_POST['id'];
$nome =    $_POST['nome'];
$link =    $_POST['imagem'];
$descricao = $_POST['descricao'];
$preco = $_POST['preco'];

$sql2 = mysqli_query($conn, "SELECT * FROM jogos 
WHERE id='$id'");

$sql = "UPDATE jogos SET nome='$nome', imagem='$link', 
descricao='$descricao', preco='$preco' WHERE id=$id";
$altera = mysqli_query($conn, $sql);

if(!$altera){
    echo "Ocorreu um erro ao atualizar dados no banco de dados. <br>
    <a href='?pg=listar'>Voltar</a>";
}else{
   echo "<h3>Alterado com sucesso!</h3>
<a href='?pg=listar'>Voltar</a>";
}
?>