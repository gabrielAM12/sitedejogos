<div class="container">
  <h2>Inserir Página</h2> 
  <form  id="contactForm" action="?pg=inserirdb" method="post">
     
	 <label>Nome do jogo:</label> 
     <input type="text" class="form-control" name="nome" required="" 
     data-validation-required-message="Please enter your name."><br>
	 Link da imagem: <input type="text" class="form-control" name="imagem" required><br>
	 Descrição do jogo:<textarea class="form-control" name="descricao" rows="5" cols="10"
      required></textarea><br>
    <label>Preço do jogo:</label> 
     <input type="num" class="form-control" name="preco" required="" 
     data-validation-required-message="Informe o preço do jogo."><br>  
	 <button type="submit" class="btn btn-primary">Enviar</button>
     <button type="cancel" class="btn btn-primary">Cancelar</button>

  </form>
</div>