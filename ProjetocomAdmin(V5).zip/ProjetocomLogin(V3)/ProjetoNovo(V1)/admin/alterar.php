<?php

$id = $_GET['id'];
$sql = "SELECT * FROM jogos WHERE id = $id";
$busca = mysqli_query($conn, $sql);

while($dados=mysqli_fetch_array($busca)){
    
?>

<form action="?pg=alterardb" method="post">
    <input type="hidden" name="id" value="<?=$dados['id'];?>"> 
<table>
    <tr>
        <td>Nome do jogo: </td>
        <td><input name="nome" type="text" value="<?=$dados['nome'];?>"/></td>
    </tr>
    <tr> 
        <td>Link da imagem do jogo: </td>
        <td><input name="imagem" type="url" value="<?=$dados['imagem'];?>"/></td>
    </tr>
    <tr>
        <td>Descrição do jogo: </td>
        <td><textarea name="descricao" value="<?=$dados['descricao'];?>"><?=$dados['descricao'];?></textarea></td>
    </tr>
    <tr> 
        <td>Preço do jogo: </td>
        <td><input name="preco" type="number" value="<?=$dados['preco'];?>"/></td>
    </tr>
    <tr>
        <td></td>
        <td><button name="Enviar">Cadastrar</button></td>
    </tr>
</table>
</form>
<?php 
}
?>