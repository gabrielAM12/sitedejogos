<?php
$id = $_GET['jogo'];
$sql = "SELECT `id`, `nome`, `imagem`, `descricao`, `preco` FROM `jogos` WHERE id=$id";
$todos = mysqli_query($conn, $sql);
$dados=mysqli_fetch_array($todos);

?>



<h1><?=$dados['nome'];?></h1>