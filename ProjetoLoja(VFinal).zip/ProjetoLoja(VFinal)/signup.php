



<!doctype html>
<html lang="pt-br">
  <head>
    <?php
    session_start();
    ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    

    

  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">

    
    <!-- Custom styles for this template -->
    <link href="css/signin.css" rel="stylesheet">
  </head>
  <body class="text-center">
    
<main class="form-signin w-100 m-auto">
  <form action="cadastrar.php" method="POST" id='logar'>
    <h1 class="h3 mb-3 fw-normal">Faça o seu Cadastro</h1>
        
    <div class="form-floating">
      <input type="text" name="nome" class="form-control" id="floatingInput" placeholder="username">
      <label for="floatingInput">Digite o nome de usuário</label>
    </div>

    <div class="form-floating">
      <input type="email" name="usuario" class="form-control" id="floatingInput" placeholder="name@example.com">
      <label for="floatingInput">Endereço de e-mail</label>
    </div>
    <div class="form-floating">
      <input type="password" name="senha" class="form-control" id="floatingPassword" placeholder="Password">
      <label for="floatingPassword">Senha</label>
    </div>

    <button class="w-100 btn btn-lg btn-primary" type="submit">Cadastrar-se</button>
    <p class="mt-5 mb-3 text-muted">Iniciar sessão: <a href="logar.php">aqui</a></p>
    <p class="mt-5 mb-3 text-muted">Voltar para a página inicial: <a href="index.php">aqui</a></p>
  </form>
</main>


    
  </body>
</html>