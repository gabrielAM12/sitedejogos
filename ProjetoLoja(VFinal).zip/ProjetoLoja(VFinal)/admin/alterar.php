<?php

$id = $_GET['id'];
$sql = "SELECT * FROM jogos WHERE id = $id";
$busca = mysqli_query($conn, $sql);

while($dados=mysqli_fetch_array($busca)){
    
?>

<form action="alterardb.php" method="post">
    <input type="hidden" name="id" value="<?=$dados['id'];?>"> 
<table>
    <tr>
        <td>Nome do jogo: </td>
        <td><input name="nome" type="text" value="<?=$dados['nome'];?>"/></td>
    </tr>
    <tr> 
        <td>Link da imagem da capa do jogo: </td>
        <td><input name="imagem" type="url" value="<?=$dados['imagem'];?>"/></td>
    </tr>
    <tr> 
        <td>Link da imagem 1 do jogo: </td>
        <td><input name="imagem2" type="url" value="<?=$dados['imagem2'];?>"/></td>
    </tr>
    <tr> 
        <td>Link da imagem 2 do jogo: </td>
        <td><input name="imagem3" type="url" value="<?=$dados['imagem3'];?>"/></td>
    </tr>
    <tr> 
        <td>Link da imagem 3 do jogo: </td>
        <td><input name="imagem4" type="url" value="<?=$dados['imagem4'];?>"/></td>
    </tr>

    <tr>
        <td>Descrição do jogo: </td>
        <td><textarea name="descricao" value="<?=$dados['descricao'];?>"><?=$dados['descricao'];?></textarea></td>
    </tr>
    <tr> 
        <td>Preço do jogo: </td>
        <td><input name="preco" type="number" value="<?=$dados['preco'];?>"/></td>
    </tr>
    <tr>
        <td>Categoria do jogo: </td>
        <td><textarea name="categoria" value="<?=$dados['categoria'];?>"><?=$dados['categoria'];?></textarea></td>
    </tr>
    <tr>
        <td>Data de lançamento do jogo: </td>
        <td><textarea name="datal" value="<?=$dados['datal'];?>"><?=$dados['datal'];?></textarea></td>
    </tr>
    <tr> 
        <td>Classificação indicativa do jogo: </td>
        <td><input name="idade" type="number" value="<?=$dados['idade'];?>"/></td>
    </tr>

    <tr>
        <td></td>
        <td><button name="Enviar">Cadastrar</button></td>
    </tr>
</table>
</form>
<?php 
}
?>