<html>
<head>
    <title>Página Admin</title>
</head>
<body>
	<?php
    	include("../config.inc.php");

		require_once("verifica_cookies.php");

	?>

    <h2 class="page-header">Esse é o Painel Admin | 
		<a href="?pg=logout" class="btn btn-primary">
        SAIR</a></h2>
		<a href="../index.php" class="btn btn-primary">
        Voltar para a página inicial</a></h2>

	<div class='container'>
    <p>
        <a href="inserir.php" class="btn btn-primary">
        Inserir Nova Página</a>
    </p>

	<?php

	if(empty($_SERVER["QUERY_STRING"])){
	        $var = "listar.php";
	        include_once("$var");
	}else{
	        $pg = $_GET['pg'];
	        include_once("$pg.php");
	}
	?>
	</div>
</body>
</html>