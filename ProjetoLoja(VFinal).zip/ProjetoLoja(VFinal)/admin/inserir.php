<div class="container">
  <h2>Inserir Página</h2> 
  <form  id="contactForm" action="inserirdb.php" method="post">
     
	 <label>Nome do jogo:</label> 
     <input type="text" class="form-control" name="nome" required="" 
     data-validation-required-message="Please enter your name."><br>
	 Link da imagem da capa do jogo: <input type="text" class="form-control" name="imagem" required><br>
   Link da imagem 1 do jogo: <input type="text" class="form-control" name="imagem2" required><br>
   Link da imagem 2 do jogo: <input type="text" class="form-control" name="imagem3" required><br>
   Link da imagem 3 do jogo: <input type="text" class="form-control" name="imagem4" required><br>
	 Descrição do jogo:<textarea class="form-control" name="descricao" rows="5" cols="10" required></textarea><br>
   Categoria do jogo:<textarea class="form-control" name="categoria" rows="2" cols="2" required></textarea><br>
   Data de lançamento do jogo:<textarea class="form-control" name="datal" rows="2" cols="2" required></textarea><br>
    <label>Preço do jogo:</label> 
     <input type="num" class="form-control" name="preco" required="" data-validation-required-message="Informe o preço do jogo."><br>
     <label>Classificação indicativa do jogo:</label> 
     <input type="num" class="form-control" name="idade" required="" data-validation-required-message="Informe a classificação indicativa do jogo."><br>
     
	 <button type="submit" class="btn btn-primary">Enviar</button>
     <button type="cancel" class="btn btn-primary">Cancelar</button>

  </form>
</div>