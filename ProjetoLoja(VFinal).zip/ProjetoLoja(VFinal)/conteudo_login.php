<?php
include('verifica_login.php');
?>

<h2 class="text-white">Olá, <?php echo $_SESSION['nome'];?></h2>
<br>

<div id=painel>
    <div class="row row-cols-1 row-cols-md-3 g-4" id="fundopainel">
      <?php
      $sql = "SELECT `id`, `nome`, `imagem`, `descricao`, `preco` FROM `jogos` WHERE 1";

      $todos = mysqli_query($conn, $sql);

      while ($dados=mysqli_fetch_array($todos)) {?>

      <div class="col">
        <a href="?pg=app&jogo=<?=$dados['id'];?>" class="nav-link">
          <div class="card">
            <img src="<?=$dados['imagem'];?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title"><?=$dados['nome'];?></h5>
              <p class="card-text"><?=$dados['descricao'];?></p>
              <h8 class="card-text" id="preco">R$ <?=$dados['preco'];?></h8>
              
              
            </div>
          </div>
          
        </a>  
      </div>
      
      <?php } ?>
      
    </div>
  </div>
  <br>
  <h2><a href="logout.php">Sair</a></h2>


</main>


   
  </body>
</html>
