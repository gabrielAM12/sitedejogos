<?php

    $nome = $_POST['nome'];
    $link = $_POST['imagem'];
    $descricao = $_POST['descricao'];
    $preco = $_POST['preco'];
    $imagem2 = $_POST['imagem2'];
    $imagem3 = $_POST['imagem3'];
    $imagem4 = $_POST['imagem4'];
    $idade = $_POST['idade'];
    $categoria = $_POST['categoria'];
    $data = $_POST['datal'];
    include "../config.inc.php";
    

   $sql = "INSERT INTO jogos (nome, 
    imagem, descricao,preco,imagem2,imagem3,imagem4,idade,categoria,datal) 
    VALUES ('$nome','$link','$descricao','$preco','$imagem2','$imagem3','$imagem4','$idade','$categoria','$data')";

    $insert = mysqli_query($conn, $sql);

    if(!$insert){
        echo "Ocorreu um erro ao cadastrar no banco de dados. 
        <a href='inserir.php'>Tente Novamente</a>";
    }else{
       echo "<h3>Página Cadastrada com sucesso!</h3><br>";
       echo "<a href='inserir.php'>
       Cadastrar Novamente</a><br>";
       echo "<a href='listar.php'>
       Voltar para o Inicio</a><br>";
    }

?>