<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">

    <title>Login Admin</title>


  </head>

  <body class="text-center">
    <form class="form-signin" action="acesso.php" method="post">
      <h1 class="h3 mb-3 font-weight-normal">Área Restrita</h1>
      <label for="inputEmail" class="sr-only">Usuário</label>
      <input type="text" name="login" class="form-control" placeholder="usuario" required autofocus>
      <label for="inputPassword" class="sr-only">Senha</label>
      <input type="password" name="senha" class="form-control" placeholder="senha" required>
      <button class="btn btn-lg btn-primary btn-block" type="submit">Entrar</button>
    </form>
  </body>
</html>