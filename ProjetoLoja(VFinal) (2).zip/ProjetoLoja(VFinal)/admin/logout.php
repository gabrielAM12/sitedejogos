<?php

    setcookie("login");
    setcookie("senha");

    header("location:login.php");

?>