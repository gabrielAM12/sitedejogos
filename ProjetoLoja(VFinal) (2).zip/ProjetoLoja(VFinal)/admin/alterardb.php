<?php

$id =      $_POST['id'];
$nome =    $_POST['nome'];
$link =    $_POST['imagem'];
$descricao = $_POST['descricao'];
$preco = $_POST['preco'];
$imagem2 = $_POST['imagem2'];
$imagem3 = $_POST['imagem3'];
$imagem4 = $_POST['imagem4'];
$idade = $_POST['idade'];
$categoria = $_POST['categoria'];
$data = $_POST['datal'];
include "../config.inc.php";


$sql2 = mysqli_query($conn, "SELECT * FROM jogos 
WHERE id='$id'");

$sql = "UPDATE jogos SET nome='$nome', imagem='$link', 
descricao='$descricao', preco='$preco' , imagem2='$imagem2' , imagem3='$imagem3' , imagem4='$imagem4'
, idade='$idade', categoria='$categoria' , datal= '$data' WHERE id=$id";
$altera = mysqli_query($conn, $sql);

if(!$altera){
    echo "Ocorreu um erro ao atualizar dados no banco de dados. <br>
    <a href='listar.php'>Voltar</a>";
}else{
   echo "<h3>Alterado com sucesso!</h3>
<a href='listar.php'>Voltar</a>";
}
?>