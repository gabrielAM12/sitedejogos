  <!doctype html>
<html lang="pt-br">
  <head>
    <?php
    session_start();
    ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    

    

  <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">

    
    <!-- Custom styles for this template -->
    <link href="css/signin.css" rel="stylesheet">
  </head>
  <body class="text-center">
    
<main class="form-signin w-100 m-auto">
  <form action="login.php" method="POST" id='logar'>
    <h1 class="h3 mb-3 fw-normal">Iniciar sessão</h1>
    <?php
    if(isset($_SESSION['nao_autenticado'])):
    ?>
    <div class="alert alert-danger" role="alert">
        <p>ERRO: Usuário ou senha inválidos.</p>
    </div>
    <?php
    endif;
    unset($_SESSION['nao_autenticado']);
    ?>

    <div class="form-floating">
      <input type="email" name="usuario" class="form-control" id="floatingInput" placeholder="name@example.com">
      <label for="floatingInput">Endereço de e-mail</label>
    </div>
    <div class="form-floating">
      <input type="password" name="senha" class="form-control" id="floatingPassword" placeholder="Password">
      <label for="floatingPassword">Senha</label>
    </div>

    <button class="w-100 btn btn-lg btn-primary" type="submit">Logar</button>
    <p class="mt-5 mb-3 text-muted">Crie uma conta: <a href="signup.php">aqui</a></p>
    <p class="mt-5 mb-3 text-muted">Voltar para a página inicial:<a href="index.php">Início</a></p>
  </form>
</main>


    
  </body>
</html>


    
