<?php
session_start();
include('config.inc.php');

if(empty($_POST['usuario']) || empty($_POST['senha'])) {
	header('index.php?pg=conteudo_login');
	exit();
}

$usuario = mysqli_real_escape_string($conn, $_POST['usuario']);
$senha = mysqli_real_escape_string($conn, $_POST['senha']);

$query = "select id, nome from usuario where usuario = '{$usuario}' and senha = md5('{$senha}')";

$result = mysqli_query($conn, $query);

$row = mysqli_num_rows($result);

if($row == 1) {
	$usuario_db = mysqli_fetch_assoc($result);
	$_SESSION['nome'] = $usuario_db['nome'];
	header('Location: index.php?pg=conteudo_login');
	exit();
} else {
	$_SESSION['nao_autenticado'] = true;
	header('Location: logar.php');
	exit();
}