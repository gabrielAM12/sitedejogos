<?php
$id = $_GET['jogo'];
$sql = "SELECT `id`, `nome`, `imagem`, `descricao`, `preco`, `imagem2`, `imagem3`, `imagem4`, `categoria`, `idade`, `datal` FROM `jogos` WHERE id=$id";
$todos = mysqli_query($conn, $sql);
$dados=mysqli_fetch_array($todos);

?>



<div class="card mb-3" style="background-color: rgba(255, 255, 255, 0)">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="<?=$dados['imagem'];?>" class="img-fluid rounded-start" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title"><?=$dados['nome'];?></h5>
        <p class="card-text"><?=$dados['descricao'];?></p>
        <p class="card-text">Categoria: <?=$dados['categoria'];?></p>
        <p class="card-text">Data de lançamento: <?=$dados['datal'];?></p>
        <p class="card-text">Classificação indicativa: <?=$dados['idade'];?> anos</p>

      </div>
    </div>
  </div>
</div>

<div id="carouselExampleDark" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="10000">
      <img src="<?=$dados['imagem2'];?>" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item" data-bs-interval="2000">
      <img src="<?=$dados['imagem3'];?>" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="<?=$dados['imagem4'];?>" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
  
<br>
<div class="comprar">
  <h3 class="text-white">Comprar <?=$dados['nome'];?></h3>
  <span>
    <span>
    <p class="text-white">R$ <?=$dados['preco'];?></p>
    </span>
    <button type="button" class="btn btn-success">Comprar</button>
  </span>
</div>

