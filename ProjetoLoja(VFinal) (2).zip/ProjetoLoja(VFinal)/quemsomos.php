<div class="text-white">
    <h2>QUEM SOMOS</h2>
    <p>Desenvolvedores: Gabriel de Almeida Mangueira e Victor de Almeida Mangueira</p>
    <br>
    <p>Os preços dos produtos nesse site são meramente ilustrativos. Não é possível fazer a compra de nenhum jogo diretamente nesse site.</p>
</div>

<!-- Mostrar uma descrição da história da empresa e utilidade do site!  -->

