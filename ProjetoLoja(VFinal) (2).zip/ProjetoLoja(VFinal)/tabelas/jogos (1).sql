-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 04-Dez-2022 às 21:32
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `minisite`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `jogos`
--

CREATE TABLE `jogos` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `imagem` varchar(1000) NOT NULL,
  `descricao` text NOT NULL,
  `preco` float NOT NULL,
  `imagem2` varchar(300) NOT NULL,
  `imagem3` varchar(300) NOT NULL,
  `imagem4` varchar(300) NOT NULL,
  `categoria` varchar(100) NOT NULL,
  `idade` int(11) NOT NULL,
  `datal` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `jogos`
--

INSERT INTO `jogos` (`id`, `nome`, `imagem`, `descricao`, `preco`, `imagem2`, `imagem3`, `imagem4`, `categoria`, `idade`, `datal`) VALUES
(1, 'Injustice', 'https://cdn.cloudflare.steamstatic.com/steam/apps/242700/header.jpg?t=1592590114', 'Injustice: Gods Among Us Ultimate Edition aprimora o novo e ousado jogo de luta da NetherRealm Studios. Com seis personagens novos, mais de 30 skins atuais e 60 missões inéditas dos Laboratórios S.T.A.R., esta edição vai causar impacto.\r\n', 90, 'https://cdn.cloudflare.steamstatic.com/steam/apps/242700/ss_7384337f4885916ed88f4260ca259fdd0718e72c.1920x1080.jpg?t=1592590114', 'https://cdn.cloudflare.steamstatic.com/steam/apps/242700/ss_7c0dbb126a7098f43d716df45e214a86c6cab6ae.1920x1080.jpg?t=1592590114', 'https://cdn.cloudflare.steamstatic.com/steam/apps/242700/ss_0015f0630ed74f9520f134ee43fb3df3b49c7d13.1920x1080.jpg?t=1592590114', 'Luta', 12, '12 de novembro de 2013'),
(2, 'Injustice 2', 'https://cdn.cloudflare.steamstatic.com/steam/apps/627270/header.jpg?t=1573860511', 'Crie uma versão aperfeiçoada e suprema das suas lendas favoritas da DC no INJUSTICE 2. Mas esta é a sua Lenda. Sua Aventura. Seu Injustice.\r\n', 229, 'https://cdn.cloudflare.steamstatic.com/steam/apps/627270/ss_5d23a78b6a43cc6cea92166b101bd28351030f59.600x338.jpg?t=1573860511', 'https://cdn.cloudflare.steamstatic.com/steam/apps/627270/ss_297cb766d40b263bd630ac48abb3fafc6a221987.600x338.jpg?t=1573860511', 'https://cdn.cloudflare.steamstatic.com/steam/apps/627270/ss_2220435653ad0bc7fe6d512dca5e542521be2dfb.600x338.jpg?t=1573860511', 'Luta', 14, '30 de novembro de 2017'),
(3, 'EA SPORTS FIFA 23', 'https://cdn.cloudflare.steamstatic.com/steam/apps/1811260/header_alt_assets_0.jpg?t=1669311247', 'Viva a emoção do maior torneio do futebol com a atualização da FIFA World Cup™ masculina para o EA SPORTS™ FIFA 23, disponível a partir de 9 de novembro, sem custo adicional!\r\n', 299, 'https://cdn.cloudflare.steamstatic.com/steam/apps/1811260/ss_55f92d533bc6acc5bf68020ee16a2f4740ffe31d.600x338.jpg?t=1669311247', 'https://cdn.cloudflare.steamstatic.com/steam/apps/1811260/ss_b11ed2d9359cfce8e9c693c85c95b5e5ea12bcec.600x338.jpg?t=1669311247', 'https://cdn.cloudflare.steamstatic.com/steam/apps/1811260/ss_a7952f00209d661a0f05899b6567a4ddc4c43deb.600x338.jpg?t=1669311247', 'Esportes', 3, '30 de setembro de 2022'),
(4, 'FINAL FANTASY XV WINDOWS EDITION', 'https://cdn.cloudflare.steamstatic.com/steam/apps/637650/header.jpg?t=1592962568', 'Parta nesta jornada, agora com qualidade definitiva. Com muito conteúdo bônus e suporte a gráficos em Ultra High-Resolution e HDR 10, agora você pode viver a experiência maravilhosa e bem feita de FINAL FANTASY XV como nunca antes.\r\n', 125, 'https://cdn.cloudflare.steamstatic.com/steam/apps/637650/ss_999e73c2cb361d41451d1a84d85f3ff59aa30110.600x338.jpg?t=1592962568', 'https://cdn.cloudflare.steamstatic.com/steam/apps/637650/ss_a0b73e5c079a92658622b3fa05c5a6c151907baa.600x338.jpg?t=1592962568', 'https://cdn.cloudflare.steamstatic.com/steam/apps/637650/ss_2bb6ae8061af8d4b53ab21b84a9a2f40b1f8a837.600x338.jpg?t=1592962568', 'JRPG', 12, '6 de março de 2018');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `jogos`
--
ALTER TABLE `jogos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `jogos`
--
ALTER TABLE `jogos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
