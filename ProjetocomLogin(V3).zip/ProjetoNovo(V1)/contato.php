<div class="container contato">
  <h2 class="text-white">FALE CONOSCO</h2> 
  <form  id="contactForm" action="?pg=contatodb" method="post">
     
	 <label class="text-white">Nome:</label> <input type="text" class="form-control" name="nome" required="" data-validation-required-message="Please enter your name.">
	 <label class="text-white">E-mail:</label> <input type="email" class="form-control" name="email"/>
	 <label class="text-white">Telefone:</label> <input type="tel" class="form-control" name="telefone"/>
	 <label class="text-white">Assunto:</label> <input type="text" class="form-control" name="assunto"/>
	 <label class="text-white">Descreva com detalhes o problema encontrado no site:</label><textarea class="form-control" name="mensagem" rows="5" cols="10"></textarea><br>
	 <button type="submit" class="btn btn-primary">Enviar</button>
  </form>
</div>
    <!-- colocar uma caixa de texto para feedback e mostrar o telefone comercial e email da empresa.
    colocar caixa para informar o estado a cidade e o endereço.
    
    
    -->