<script language='javascript'>

function confirmaExclusao