<div id=painel>
  <div class="row row-cols-1 row-cols-md-3 g-4" id="fundopainel">
    <div class="col">
      <div class="card">
        <img src="https://cdn.akamai.steamstatic.com/steam/apps/1593500/header.jpg?t=1650554420" class="card-img-top imagem" alt="...">
        <div class="card-body">
          <h5 class="card-title">God of War</h5>
          <p class="card-text">Com a vingança contra os deuses do Olimpo em um passado distante, Kratos agora vive como um mortal no reino dos deuses e monstros nórdicos. É nesse mundo duro e implacável que ele deve lutar para sobreviver... e ensinar seu filho a fazer o mesmo.</p>
        </div>
      </div>
    </div>
    <div class="col">
      <a href="https://store.steampowered.com/app/627270/Injustice_2/" class="nav-link">
        <div class="card">
          <img src="https://cdn.akamai.steamstatic.com/steam/apps/627270/header.jpg?t=1573860511" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Injustice 2</h5>
            <p class="card-text">Crie uma versão aperfeiçoada e suprema das suas lendas favoritas da DC no INJUSTICE 2. Mas esta é a sua Lenda. Sua Aventura. Seu Injustice.</p>
            <h8 class="card-text preco" id="preco">R$ 199,00</h8>
            
            
          </div>
        </div>
      </a>
      
    </div>
    <div class="col">
      <div class="card">
        <img src="https://cdn.akamai.steamstatic.com/steam/apps/637650/header.jpg?t=1592962568" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">FINAL FANTASY XV</h5>
          <p class="card-text">Parta nesta jornada, agora com qualidade definitiva. Com muito conteúdo bônus e suporte a gráficos em Ultra High-Resolution e HDR 10, agora você pode viver a experiência maravilhosa e bem feita de FINAL FANTASY XV como nunca antes.</p>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <img src="https://cdn.akamai.steamstatic.com/steam/apps/1811260/header_alt_assets_0.jpg?t=1668091575" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">EA SPORTS FIFA 23</h5>
          <p class="card-text">Viva a emoção do maior torneio do futebol com a atualização da FIFA World Cup™ masculina para o EA SPORTS™ FIFA 23, disponível a partir de 9 de novembro, sem custo adicional!</p>
        </div>
      </div>
    </div>
  </div>
</div>


</main>


    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>


<!-- imagens, preços,links para redirecionamento de produtos e categorias dos produtos -->