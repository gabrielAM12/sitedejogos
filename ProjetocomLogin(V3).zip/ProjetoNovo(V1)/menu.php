<!--<a href="?pg=conteudo">Home</a>
<span> | </span>
<a href="?pg=quemsomos">Quem somos</a>
<span> | </span>
<a href="?pg=contato">Fale Conosco</a>
rodape e categorias/produtos -->