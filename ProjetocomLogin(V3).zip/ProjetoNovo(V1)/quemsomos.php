<div class="text-white">
    <h2>QUEM SOMOS</h2>
    <p>Criado na década de 50, em Franca, no interior de São Paulo, o Magazine Luiza tornou-se uma companhia orientada por ciclos de desenvolvimento. A definição desses ciclos - com começo, meio e fim e que podem ser contados por intermédio de narrativas claras - começou na gestão de Luiza Helena Trajano como CEO, pautou o mandato de Marcelo Silva na liderança da empresa, e desde 2016, marca a gestão de Frederico Trajano. O Magalu já viveu o ciclo da expansão pelo interior do Brasil, o ciclo da entrada no mercado de São Paulo e de consolidação como umas das grandes varejistas brasileiras, o ciclo da busca por escala e abrangência regional via aquisições, o ciclo da transformação digital. Todos eles foram concluídos. A partir de 2019, iniciou-se um novo momento -- o posicionamento do Magalu como uma plataforma digital de varejo, um ecossistema que contribui para que milhares de outros negócios ingressem no universo digital.</p>
    <br>
    <p>Cinco pilares sustentam este novo ciclo de negócios do Magalu -- novas categorias, Superapp, entrega mais rápida, o Magalu ao seu Serviço (ou Magalu as a Service) e a Fintech. O desafio dos mais de 40 000 colaboradores da empresa é fortalecer esses pilares para que o ecossistema digital funcione de forma plena. Assim como das nossas empresas parceiras: Netshoes, Zattini, LogBee, Época Cosméticos, Estante Virtual, Consórcio Magalu, entre outras.</p>
</div>

<!-- Mostrar uma descrição da história da empresa e utilidade do site!  -->

