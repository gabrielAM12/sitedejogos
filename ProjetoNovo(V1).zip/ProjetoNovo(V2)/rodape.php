<div  id="rodape">
    <br>
    <br>
    <p>Preços e condições de pagamento exclusivos para compras via internet, podendo variar nas lojas físicas. Ofertas válidas na compra de até 5 peças de cada produto por cliente, até o término dos nossos estoques para internet. Caso os produtos apresentem divergências de valores, o preço válido é o da sacola de compras.</p>
    <p>Vendas sujeitas a análise e confirmação de dados.</p>
    <a href="?pg=contato">Fale Conosco</a>
</div>

<!-- fale conosco, redirecionar para o começo do site e checar sites -->
</body>
</html>